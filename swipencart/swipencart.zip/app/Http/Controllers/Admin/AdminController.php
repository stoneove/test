<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\admin;
use Auth;
use Hash;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {

        return view('admins.dashboard');

    }
    public function adminlogin(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->all();
   
            $request->validate([
                'email' => 'required|email|max:255',
                'password' => 'required|max:255',
            ]);
            if (Auth::guard('admin')->attempt(['email' => $data['email'], 'password' => $data['password'], 'status' => 1])) {
                return redirect('admin/dashboard');
            } elseif (!Auth::guard('admin')->attempt(['email' => $data['email'], 'password' => $data['password'], 'status' => 1])) {
                return redirect()->back()->with('message', 'The user not is available you have to signup first...');
            }
        }
        return view('admins.login');

    
    }
    public function adminlogout()
    {

        Auth::guard('admin')->logout();
        return redirect(
            'admin/login'
        );
    }

    public function passwordupdate(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->all();
            $request->validate([

                'currentpassword' => 'required|max:255',
                'newpassword' => 'required|max:255',
                'confirmpassword' => 'required|same:newpassword',
            ]);
            if (Hash::check($data['currentpassword'], Auth::guard('admin')->user()->password)) {
                if ($data['newpassword'] == $data['confirmpassword']) {

                    Admin::where('id', Auth::guard('admin')->user()->id)->update(['password' => Hash::make($data['newpassword'])]);
                    return redirect()->back()->with('success', 'Password update successfully');
                }

            } else {
                return redirect()->back()->with('message', 'Your current password is Incorrect');
            }
        }
        return view('admins.updatepassword');

    }

    public function check_current_password(Request $request)
    {
        // through ajax code in custom.js
        $data = $request->all();
        if (Hash::check($data['currentpassword'], Auth::guard('admin')->user()->password)) {
            return 'true';
        } else {
            return 'false';
        }

    }
    public function profileupdate(Request $request)
    {
        $request->validate([

            'name' => 'required|regex:/(^([a-zA-Z]+)(\d+)?$)/u|max:100',
            'mobile' => 'required|max:11',

        ]);
        $data = $request->all();
        $id = Admin::where('id', Auth::guard('admin')->user()->id)->update(['name'=>$request['name']],['mobile'=>$request['mobile']]);
        return redirect()->back()->with('success_profile','profile update successfully');
         
    }
    public function detailupdate(Request $request)
    {
        return view('admins.updatedetails');
    }

}
