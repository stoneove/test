<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Fillow : Fillow Saas Admin  Bootstrap 5 Template">
	<meta property="og:title" content="Fillow : Fillow Saas Admin  Bootstrap 5 Template">
	<meta property="og:description" content="Fillow : Fillow Saas Admin  Bootstrap 5 Template">
	<meta property="og:image" content="https:/fillow.dexignlab.com/xhtml/social-image.png">
	<meta name="format-detection" content="telephone=no">
	
	<!-- PAGE TITLE HERE -->
	<title>Admin Dashboard</title>
	
	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('vendors/images/favicon.png')); ?>">
	<link href="<?php echo e(url('vendors/vendor/jquery-nice-select/css/nice-select.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(url('vendors/vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(url('vendors/vendor/nouislider/nouislider.min.css')); ?>">
	
	<link rel="stylesheet" href="<?php echo e(url('vendors/vendor/toastr/css/toastr.min.css')); ?>">


	<!-- Style css -->
    <link href="<?php echo e(url('vendors/css/style.css')); ?>" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.min.js"></script>
</head>
<body >

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
		<div class="lds-ripple">
			<div></div>
			<div></div>
		</div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
	<?php echo $__env->make('vendors.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
	<?php echo $__env->make('vendors.layouts.chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
 <?php echo $__env->make('vendors.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
<?php echo $__env->make('vendors.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
   <?php echo $__env->yieldContent('content'); ?>
        <!--**********************************
            Content body end
        ***********************************-->
		


		
        <!--**********************************
            Footer start
        ***********************************-->
  <?php echo $__env->make('vendors.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************-->



    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(url('vendors/vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/vendor/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(url('vendors/vendor/apexchart/apexchart.js')); ?>"></script>
	
	<script src="<?php echo e(url('vendors/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(url('vendors/vendor/peity/jquery.peity.min.js')); ?>"></script>
	<!-- Dashboard 1 -->
	<script src="<?php echo e(url('vendors/js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(url('vendors/vendor/owl-carousel/owl.carousel.js')); ?>"></script>
	
    <script src="<?php echo e(url('vendors/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendors/js/custom.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/js/dlabnav-init.js')); ?>"></script>
	<script src="<?php echo e(url('vendors/js/demo.js')); ?>"></script>
    <script src="<?php echo e(url('vendors/js/styleSwitcher.js')); ?>"></script>
	


   <!-- Toastr -->
   <script src="<?php echo e(url('vendors/vendor/toastr/js/toastr.min.js')); ?>"></script>

   <!-- All init script -->
   <script src="<?php echo e(url('vendors/js/plugins-init/toastr-init.js')); ?>"></script>
	<script>
		function cardsCenter()
		{
			
			/*  testimonial one function by = owl.carousel.js */
			
	
			
			jQuery('.card-slider').owlCarousel({
				loop:true,
				margin:0,
				nav:true,
				//center:true,
				slideSpeed: 3000,
				paginationSpeed: 3000,
				dots: true,
				navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
				responsive:{
					0:{
						items:1
					},
					576:{
						items:1
					},	
					800:{
						items:1
					},			
					991:{
						items:1
					},
					1200:{
						items:1
					},
					1600:{
						items:1
					}
				}
			})
		}
		
		jQuery(window).on('load',function(){
			setTimeout(function(){
				cardsCenter();
			}, 1000); 
		});
		
	</script>
	

</body>
</html><?php /**PATH C:\xampp\htdocs\multi_vendor\swipencart\resources\views/vendors/layouts/layout.blade.php ENDPATH**/ ?>