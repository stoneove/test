
<?php $__env->startSection('content'); ?>



    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles mt-3">
                <ol class="breadcrumb ">
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Password</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Update</a></li>
                </ol>
            </div>
            <!-- row -->
            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="breadcrumb-item">UPDATE YOUR PASSWORD TO SECURE YOUR DASHBOARD...</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">


                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(Session::get('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-primary">
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>





                                <form method="post" action="<?php echo e(url('vendor/password-update')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label class="text-label form-label" for="validationCustomUsername">Email</label>
                                        <div class="input-group">
                                            <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                            <input type="text" class="form-control" id="validationCustomUsername"
                                                placeholder="Enter a username.." required="" readonly
                                                value="<?php echo e(Auth::guard('vendor')->user()->email); ?>">
                                            <div class="invalid-feedback">
                                                Please Enter a username.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="text-label form-label" for="validationCustomUsername">Admin
                                            Type</label>
                                        <div class="input-group">
                                            <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                            <input type="text" class="form-control" id="validationCustomUsername"
                                                placeholder="Enter a username.." required="" readonly
                                                value="<?php echo e(Auth::guard('vendor')->user()->name); ?>">
                                            <div class="invalid-feedback">
                                                Please Enter a username.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="text-label form-label" for="dlab-password">Old Password<span
                                                style="color:rgb(255, 0, 0)"> *</span></label>
                                        <div class="input-group transparent-append">
                                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                            <input type="password" class="form-control currentpasswordvendor"
                                                name="currentpassword" id="dlab-password" placeholder="Choose a safe one.."
                                                required="">
                                            <span class="input-group-text show-pass">
                                                <i class="fa fa-eye-slash"></i>
                                                <i class="fa fa-eye"></i>
                                            </span>
                                            <div class="invalid-feedback">
                                                Please Enter a username.
                                            </div>
                                        </div>
                                        <span id="error_password_vendor" style="margin-left: 43px"></span>
                                    </div>
                                    <div class="mb-3">
                                        <label class="text-label form-label" for="dlab-password2">Update Password <span
                                                style="color:rgb(255, 0, 0)"> *</span></label>
                                        <div class="input-group transparent-append">
                                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                            <input type="password" name="newpassword" class="form-control" id="password"
                                                placeholder="Choose a safe one.." required="">

                                            <span class="input-group-text " id="togglePassword">

                                            </span>
                                            <div class="invalid-feedback">
                                                Please Enter a username.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="text-label form-label" for="dlab-password">Confirm Password<span
                                                style="color:rgb(255, 0, 0)"> *</span></label>
                                        <div class="input-group transparent-append">
                                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                            <input type="password" name="confirmpassword" class="form-control"
                                                id="password" placeholder="Choose a safe one.." required="">

                                            <div class="invalid-feedback">
                                                Please Enter a username.
                                            </div>
                                        </div>
                                        &nbsp;&nbsp;&nbsp;&nbsp; <span id="notmatchpass"></span>
                                    </div>
                                    
                                    <button type="submit"  class="btn me-3 btn-success ">Update your
                                        password</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendors.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multi_vendor\swipencart\resources\views/vendors/updatepassword.blade.php ENDPATH**/ ?>